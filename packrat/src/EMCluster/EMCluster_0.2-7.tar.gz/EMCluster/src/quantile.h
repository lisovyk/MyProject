int quantile(int n,double *x,double *p,double *q, int numqs);
double trimmed_mean(int n,double *x,double left,double right);
