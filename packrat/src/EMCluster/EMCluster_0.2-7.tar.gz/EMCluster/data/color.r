color.class <- c("#00EEEEFF", "#AAC6EEFF", "#EE66EEFF", "#EEC6BBFF",
                 "grey65", "#60FF00FF", "#A0EEEEFF", "#EECF5EFF", "grey80",
                 "#DEAA00FF", "#C9FF00FF")
