
SEXP ctree_memory (SEXP object, SEXP MP_INV);
